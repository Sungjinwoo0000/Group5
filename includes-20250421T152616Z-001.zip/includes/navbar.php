<div class="navbar">
    <div class="logo">🎓 StudentSys</div>
    <div class="nav-links">
        <a href="index.php">Home</a>
        <a href="add.php">Add Student</a>
    </div>
</div>